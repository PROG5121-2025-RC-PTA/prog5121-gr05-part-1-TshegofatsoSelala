/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class AccountCreation2Test {
    
    public AccountCreation2Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class AccountCreation2.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        AccountCreation2.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class AccountCreation2.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        Scanner scanner = null;
        AccountCreation2.registerUser(scanner);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class AccountCreation2.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        Scanner scanner = null;
        AccountCreation2.loginUser(scanner);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of startApp method, of class AccountCreation2.
     */
    @Test
    public void testStartApp() {
        System.out.println("startApp");
        Scanner scanner = null;
        AccountCreation2.startApp(scanner);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of storeMessage method, of class AccountCreation2.
     */
    @Test
    public void testStoreMessage() {
        System.out.println("storeMessage");
        Message msg = null;
        AccountCreation2.storeMessage(msg);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkUsername method, of class AccountCreation2.
     */
    @Test
    public void testCheckUsername() {
        System.out.println("checkUsername");
        String u = "";
        boolean expResult = false;
        boolean result = AccountCreation2.checkUsername(u);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPassword method, of class AccountCreation2.
     */
    @Test
    public void testCheckPassword() {
        System.out.println("checkPassword");
        String p = "";
        boolean expResult = false;
        boolean result = AccountCreation2.checkPassword(p);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkCellPhoneNumber method, of class AccountCreation2.
     */
    @Test
    public void testCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String c = "";
        boolean expResult = false;
        boolean result = AccountCreation2.checkCellPhoneNumber(c);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
