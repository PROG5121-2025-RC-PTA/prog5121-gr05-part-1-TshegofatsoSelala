
import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class AccountCreation2{
    private static String username;
    private static String password;
    private static String cellPhoneNumber;
    private static boolean loggedIn = false;
    private static final List<Message> sentMessages = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        registerUser(scanner);
        loginUser(scanner);
        if (loggedIn) startApp(scanner);
    }

    public static void registerUser(Scanner scanner) {
        System.out.println("Enter your username: ");
        username = scanner.nextLine();
        while (!checkUsername(username)) {
            System.out.println("Invalid username. Must contain '_' and max 5 chars.");
            username = scanner.nextLine();
        }

        System.out.println("Enter your password: ");
        password = scanner.nextLine();
        while (!checkPassword(password)) {
            System.out.println("Password must be 8+ chars with uppercase, number, special char.");
            password = scanner.nextLine();
        }

        System.out.println("Enter your cell number (+27 format): ");
        cellPhoneNumber = scanner.nextLine();
        while (!checkCellPhoneNumber(cellPhoneNumber)) {
            System.out.println("Invalid cell number. Format: +27XXXXXXXXX");
            cellPhoneNumber = scanner.nextLine();
        }
    }

    public static void loginUser(Scanner scanner) {
        System.out.println("Login with your username: ");
        String u = scanner.nextLine();
        System.out.println("Login with your password: ");
        String p = scanner.nextLine();

        if (u.equals(username) && p.equals(password)) {
            System.out.println("Welcome to QuickChat.");
            loggedIn = true;
        } else {
            System.out.println("Incorrect login. Exiting.");
        }
    }

    public static void startApp(Scanner scanner) {
        System.out.print("Enter number of messages to send: ");
        int total = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < total; i++) {
            System.out.println("Menu:\n1) Send Message\n2) Show Recently Sent (Coming Soon)\n3) Quit");
            int option = scanner.nextInt();
            scanner.nextLine();
            if (option == 3) break;

            if (option == 1) {
                System.out.print("Recipient number: ");
                String recipient = scanner.nextLine();
                while (!(recipient.startsWith("+") && recipient.length() <= 250)) {
                    System.out.println("Please enter a message of less than 50 characters");
                    recipient = scanner.nextLine();
                }

                System.out.print("Message: ");
                String content = scanner.nextLine();
                if (content.length() > 250) {
                    System.out.println("Too long by " + (content.length() - 250));
                    i--; continue;
                }

                Message msg = new Message(i, recipient, content);
                System.out.println("1) Send 2) Disregard 3) Store");
                int act = scanner.nextInt();
                scanner.nextLine();
                if (act == 1) sentMessages.add(msg);
                else if (act == 3) storeMessage(msg);

                JOptionPane.showMessageDialog(null, msg.details());
            } else if (option == 2) {
                System.out.println("Coming Soon.");
            }
        }

        System.out.println("Total messages sent: " + sentMessages.size());
    }

    public static void storeMessage(Message msg) {
        try (FileWriter fw = new FileWriter("stored_messages.json", true)) {
            fw.write("{\"ID\":\"" + msg.id + "\", \"Hash\":\"" + msg.hash +
                    "\", \"Recipient\":\"" + msg.recipient + "\", \"Message\":\"" + msg.content + "\"}\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean checkUsername(String u) {
        return u.contains("_") && u.length() <= 5;
    }

    public static boolean checkPassword(String p) {
        return p.length() >= 8 && p.matches(".*[A-Z].*") && p.matches(".*[0-9].*") && p.matches(".*[!@#$%^&*()].*");
    }

    public static boolean checkCellPhoneNumber(String c) {
        return c.startsWith("+27") && c.length() == 12;
    }
}

class Message {
    String id;
    int number;
    String recipient;
    String content;
    String hash;

    public Message(int num, String rec, String cont) {
        this.id = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
        this.number = num;
        this.recipient = rec;
        this.content = cont;
        this.hash = createHash();
    }

    public String createHash() {
        String[] words = content.split(" ");
        if (words.length < 2) return "BADHASH";
        return id.substring(0, 2) + ":" + number + ":" + words[0].toUpperCase() + words[words.length - 1].toUpperCase();
    }

    public String details() {
        return "MessageID: " + id + "\nMessage Hash: " + hash + "\nRecipient: " + recipient + "\nMessage: " + content;
    }
}
