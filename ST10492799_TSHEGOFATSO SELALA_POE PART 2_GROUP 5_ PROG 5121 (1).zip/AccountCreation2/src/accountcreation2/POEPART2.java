/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accountcreation2;
 import java.util.UUID;
/**
 *
 * @author RC_Student_lab
 */
public class POEPART2 {
   

public class Message {
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String content;
    private String hash;

    public Message(int messageNumber, String recipient, String content) {
        this.messageID = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.content = content;
        this.hash = createMessageHash();
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        return recipient.length() <= 10 && recipient.startsWith("+");
    }

    public String createMessageHash() {
        String[] words = content.trim().split("\\s+");
        if (words.length < 2) return "INVALIDHASH";
        return messageID.substring(0, 2) + ":" + messageNumber + ":" +
                words[0].toUpperCase() + words[words.length - 1].toUpperCase();
    }

    public String sendMessageOption(int option) {
        switch (option) {
            case 1: return "Message successfully sent.";
            case 2: return "Message disregarded.";
            case 3: return "Message stored for later.";
            default: return "Invalid option.";
        }
    }

    public String getMessageDetails() {
        return "MessageID: " + messageID + "\nHash: " + hash +
                "\nRecipient: " + recipient + "\nMessage: " + content;
    }

    public String getMessageID() {
        return messageID;
    }

    public String getHash() {
        return hash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getContent() {
        return content;
    }
}

}
