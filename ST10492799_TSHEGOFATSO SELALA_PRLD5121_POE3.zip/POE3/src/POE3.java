import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import javax.swing.JOptionPane;

public class POE3 {
    private static String username;
    private static String password;
    private static String cellPhoneNumber;
    private static boolean loggedIn = false;
    private static final List<Message> sentMessages = new ArrayList<>();
    
    // Task management arrays
    private static final List<String> developers = new ArrayList<>();
    private static final List<String> taskNames = new ArrayList<>();
    private static final List<String> taskIDs = new ArrayList<>();
    private static final List<Integer> taskDurations = new ArrayList<>();
    private static final List<String> taskStatuses = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Populate with test data
        initializeTestData();
        
        registerUser(scanner);
        loginUser(scanner);
        if (loggedIn) {
            startApp(scanner);
            manageTasks(scanner);
        }
    }

    private static void initializeTestData() {
        // Task 1
        developers.add("Mike Smith");
        taskNames.add("Create Login");
        taskIDs.add(generateTaskID());
        taskDurations.add(5);
        taskStatuses.add("To Do");

        // Task 2
        developers.add("Edward Harrison");
        taskNames.add("Create Add Features");
        taskIDs.add(generateTaskID());
        taskDurations.add(8);
        taskStatuses.add("Doing");

        // Task 3
        developers.add("Samantha Paulson");
        taskNames.add("Create Reports");
        taskIDs.add(generateTaskID());
        taskDurations.add(2);
        taskStatuses.add("Done");

        // Task 4
        developers.add("Glenda Oberholzer");
        taskNames.add("Add Arrays");
        taskIDs.add(generateTaskID());
        taskDurations.add(11);
        taskStatuses.add("To Do");
    }

    private static String generateTaskID() {
        return UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public static void manageTasks(Scanner scanner) {
        while (true) {
            System.out.println("\nTask Management Menu:");
            System.out.println("1. Display done tasks");
            System.out.println("2. Display task with longest duration");
            System.out.println("3. Search for task by name");
            System.out.println("4. Search tasks by developer");
            System.out.println("5. Delete a task");
            System.out.println("6. Display full task report");
            System.out.println("7. Exit task management");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            
            switch (choice) {
                case 1:
                    displayDoneTasks();
                    break;
                case 2:
                    displayLongestTask();
                    break;
                case 3:
                    searchTaskByName(scanner);
                    break;
                case 4:
                    searchTasksByDeveloper(scanner);
                    break;
                case 5:
                    deleteTask(scanner);
                    break;
                case 6:
                    displayFullReport();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayDoneTasks() {
        System.out.println("\nDone Tasks:");
        System.out.println("Developer\tTask Name\tDuration");
        for (int i = 0; i < taskStatuses.size(); i++) {
            if (taskStatuses.get(i).equalsIgnoreCase("Done")) {
                System.out.printf("%s\t%s\t%d%n", 
                    developers.get(i), 
                    taskNames.get(i), 
                    taskDurations.get(i));
            }
        }
    }

    private static void displayLongestTask() {
        if (taskDurations.isEmpty()) {
            System.out.println("No tasks available.");
            return;
        }
        
        int maxDuration = Collections.max(taskDurations);
        int index = taskDurations.indexOf(maxDuration);
        
        System.out.printf("\nTask with longest duration: %s, %d%n", 
            developers.get(index), 
            taskDurations.get(index));
    }

    private static void searchTaskByName(Scanner scanner) {
        System.out.print("Enter task name to search: ");
        String name = scanner.nextLine();
        
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(name)) {
                System.out.printf("\nTask found: %s, %s, %s%n", 
                    taskNames.get(i), 
                    developers.get(i), 
                    taskStatuses.get(i));
                return;
            }
        }
        System.out.println("Task not found.");
    }

    private static void searchTasksByDeveloper(Scanner scanner) {
        System.out.print("Enter developer name to search: ");
        String dev = scanner.nextLine();
        
        System.out.println("\nTasks assigned to " + dev + ":");
        System.out.println("Task Name\tStatus");
        
        boolean found = false;
        for (int i = 0; i < developers.size(); i++) {
            if (developers.get(i).equalsIgnoreCase(dev)) {
                System.out.printf("%s\t%s%n", 
                    taskNames.get(i), 
                    taskStatuses.get(i));
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No tasks found for this developer.");
        }
    }

    private static void deleteTask(Scanner scanner) {
        System.out.print("Enter task name to delete: ");
        String name = scanner.nextLine();
        
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(name)) {
                developers.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                System.out.println("Task '" + name + "' successfully deleted.");
                return;
            }
        }
        System.out.println("Task not found.");
    }

    private static void displayFullReport() {
        System.out.println("\nFull Task Report:");
        System.out.println("ID\tDeveloper\tTask Name\tDuration\tStatus");
        for (int i = 0; i < taskNames.size(); i++) {
            System.out.printf("%s\t%s\t%s\t%d\t%s%n", 
                taskIDs.get(i),
                developers.get(i),
                taskNames.get(i),
                taskDurations.get(i),
                taskStatuses.get(i));
        }
    }

    public static void registerUser(Scanner scanner) {
        System.out.println("Enter your username: ");
        username = scanner.nextLine();
        while (!checkUsername(username)) {
            System.out.println("Invalid username. Must contain '_' and max 5 chars.");
            username = scanner.nextLine();
        }

        System.out.println("Enter your password: ");
        password = scanner.nextLine();
        while (!checkPassword(password)) {
            System.out.println("Password must be 8+ chars with uppercase, number, special char.");
            password = scanner.nextLine();
        }

        System.out.println("Enter your cell number (+27 format): ");
        cellPhoneNumber = scanner.nextLine();
        while (!checkCellPhoneNumber(cellPhoneNumber)) {
            System.out.println("Invalid cell number. Format: +27XXXXXXXXX");
            cellPhoneNumber = scanner.nextLine();
        }
    }

    public static void loginUser(Scanner scanner) {
        System.out.println("Login with your username: ");
        String u = scanner.nextLine();
        System.out.println("Login with your password: ");
        String p = scanner.nextLine();

        if (u.equals(username) && p.equals(password)) {
            System.out.println("Welcome to QuickChat.");
            loggedIn = true;
        } else {
            System.out.println("Incorrect login. Exiting.");
        }
    }

    public static void startApp(Scanner scanner) {
        System.out.print("Enter number of messages to send: ");
        int total = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < total; i++) {
            System.out.println("Menu:\n1) Send Message\n2) Show Recently Sent (Coming Soon)\n3) Quit");
            int option = scanner.nextInt();
            scanner.nextLine();
            if (option == 3) break;

            if (option == 1) {
                System.out.print("Recipient number: ");
                String recipient = scanner.nextLine();
                while (!(recipient.startsWith("+") && recipient.length() <= 250)) {
                    System.out.println("Please enter a message of less than 50 characters");
                    recipient = scanner.nextLine();
                }

                System.out.print("Message: ");
                String content = scanner.nextLine();
                if (content.length() > 250) {
                    System.out.println("Too long by " + (content.length() - 250));
                    i--; continue;
                }

                Message msg = new Message(i, recipient, content);
                System.out.println("1) Send 2) Disregard 3) Store");
                int act = scanner.nextInt();
                scanner.nextLine();
                if (act == 1) sentMessages.add(msg);
                else if (act == 3) storeMessage(msg);

                JOptionPane.showMessageDialog(null, msg.details());
            } else if (option == 2) {
                System.out.println("Coming Soon.");
            }
        }

        System.out.println("Total messages sent: " + sentMessages.size());
    }

    public static void storeMessage(Message msg) {
        try (FileWriter fw = new FileWriter("stored_messages.json", true)) {
            fw.write("{\"ID\":\"" + msg.id + "\", \"Hash\":\"" + msg.hash +
                    "\", \"Recipient\":\"" + msg.recipient + "\", \"Message\":\"" + msg.content + "\"}\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean checkUsername(String u) {
        return u.contains("_") && u.length() <= 5;
    }

    public static boolean checkPassword(String p) {
        return p.length() >= 8 && p.matches(".*[A-Z].*") && p.matches(".*[0-9].*") && p.matches(".*[!@#$%^&*()].*");
    }

    public static boolean checkCellPhoneNumber(String c) {
        return c.startsWith("+27") && c.length() == 12;
    }
}

class Message {
    String id;
    int number;
    String recipient;
    String content;
    String hash;

    public Message(int num, String rec, String cont) {
        this.id = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
        this.number = num;
        this.recipient = rec;
        this.content = cont;
        this.hash = createHash();
    }

    public String createHash() {
        String[] words = content.split(" ");
        if (words.length < 2) return "BADHASH";
        return id.substring(0, 2) + ":" + number + ":" + words[0].toUpperCase() + words[words.length - 1].toUpperCase();
    }

    public String details() {
        return "MessageID: " + id + "\nMessage Hash: " + hash + "\nRecipient: " + recipient + "\nMessage: " + content;
    }
}    

